I have used Conda to manage the python environment, and Jupyter notebook to do the coding jobs. I completed this assignment with Python 3.7.6, under the help of the following python packages:
- numpy=1.17.3
- pandas=0.25.3
- matplotlib=3.1.2
- seaborn=0.9.0
- scikit-learn=0.22
- tensorflow=2.0.0
- jupyter=1.0.0
- notebook=6.0.1

The code is avaiable at: http://zhaozhen.me/assets/download/CS7641A3.zip. All the files are included at the current directory. It will be very easy to run the algorithms, as long as the correct packages are installed. Just open the notebooks, and run it cell by cell. Then all the graphs and numerical results will be generated.

Please let me know at zzhao377@gatech.edu if any problems.