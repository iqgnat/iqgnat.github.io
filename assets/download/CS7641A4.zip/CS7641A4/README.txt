Same to previous project, Conda is used to manage the python environment, and Jupyter notebook to do the coding jobs. I completed this assignment with Python 3.7.6, under the help of the following python packages:
- numpy=1.17.3
- pandas=0.25.3
- matplotlib=3.1.2
- mdptoolbox-hiive=4.0.3.1
- seaborn=0.9.0
- gym=0.17.3
- jupyter=1.0.0
- notebook=6.0.1

The main implementation of this assignments relies on mdptoolbox. The code is avaiable at: http://zhaozhen.me/assets/download/CS7641A4.zip. All the files are included at the current directory,
- ForestManagement.ipynb: for the forest problem.
- FrozenLake -stochastic movie.ipynb: for the FrozenLake problem

Just open the notebooks, and run it cell by cell. Please let me know at zzhao377@gatech.edu if any problems.