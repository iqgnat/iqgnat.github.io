I have used Conda to manage the python environment, and Jupyter notebook to do the coding jobs. I completed this assignment with Python 3.7.6, under the help of the following python packages:
- numpy=1.17.3
- pandas=0.25.3
- matplotlib=3.1.2
- seaborn=0.9.0
- scikit-learn=0.22
- tensorflow=2.0.0
- jupyter=1.0.0
- notebook=6.0.1
- mlrose-hiive=2.1.3
- mlrose=1.3.0
The main implementation of this assignments relies on the mlrose and mlrose-hiive package. Please ensure they are correctly installed.

The code is avaiable at: http://zhaozhen.me/assets/download/CS7641A2.zip. All the files are included at the current directory,
- HTRU2.csv: the pulsar candidate data
- FlipFlop-SA.ipynb: for flip flop problem (20 bits). 
- Knapsack-MIMIC.ipynb: for knapsack problem
- Queens-GA.ipynb: for the 32-queens attacks problem.
- NN-weight.ipynb: for the NN weight optimizations.

Just open the notebooks, and run it cell by cell. Please let me know at zzhao377@gatech.edu if any problems.